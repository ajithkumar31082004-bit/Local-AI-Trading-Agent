"""Isolated simulated Paper Broker for XAUTUSD on Delta Exchange India.

STRICT SAFETY GUARANTEE:
- NEVER PLACES REAL ORDERS.
- NEVER MODIFIES REAL POSITIONS OR WALLET BALANCES.
- TOTALLY DECOUPLED FROM LIVE ORDER ENDPOINTS.
- ENFORCES PERSISTENT ACCOUNT STATE ACROSS APPLICATION RESTARTS.
"""
import json
import logging
import math
import os
import secrets
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple, Union

try:
    import portalocker
except ImportError:
    portalocker = None

from config.orb_settings import ORBSettings, settings as default_orb_settings
from risk.position_size_guard import (
    validate_paper_order_lots,
    validate_contract_quantity,
    PositionSizeViolation,
    APPROVED_MAX_PAPER_LOTS,
)
from services.idempotency_registry import DurableIdempotencyRegistry, IdempotencyRegistryError
try:
    from services.governance_supervisor import GovernanceSupervisor, GovernanceContainmentError
    _SUPERVISOR_IMPORT_EXCEPTION = None
except Exception as e:
    GovernanceSupervisor = None
    GovernanceContainmentError = None
    _SUPERVISOR_IMPORT_EXCEPTION = e

logger = logging.getLogger(__name__)


class CrossProcessReentrantLock:
    """Thread-safe and cross-OS-process reentrant file lock using portalocker."""

    _instances: Dict[str, "CrossProcessReentrantLock"] = {}
    _registry_lock = threading.Lock()

    @classmethod
    def get_lock(cls, lock_file: Path, timeout: float = 10.0) -> "CrossProcessReentrantLock":
        key = str(lock_file.resolve()).lower() if os.name == "nt" else str(lock_file.resolve())
        with cls._registry_lock:
            if key not in cls._instances:
                cls._instances[key] = cls(lock_file, timeout=timeout)
            return cls._instances[key]

    def __init__(self, lock_file: Path, timeout: float = 10.0):
        self.lock_file = lock_file
        self.timeout = timeout
        self._thread_lock = threading.RLock()
        self._portalocker_lock: Optional[portalocker.Lock] = None
        self._depth = 0

    def acquire(self, timeout: Optional[float] = None) -> bool:
        t = timeout if timeout is not None else self.timeout
        self._thread_lock.acquire()
        try:
            if self._depth == 0:
                self.lock_file.parent.mkdir(parents=True, exist_ok=True)
                if portalocker is not None:
                    self._portalocker_lock = portalocker.Lock(str(self.lock_file), timeout=t)
                    self._portalocker_lock.acquire()
                else:
                    # Fail closed in production: in-process RLock cannot coordinate cross-process access.
                    # Strictly restricted to active pytest execution (PYTEST_CURRENT_TEST).
                    # Generic flags such as TEST_RUNNER or CI_TEST_MODE are rejected to prevent bypass.
                    is_pytest = bool(os.environ.get("PYTEST_CURRENT_TEST"))
                    if not is_pytest:
                        raise RuntimeError(
                            "FATAL: portalocker is required for cross-process state safety in production "
                            "trading execution. Failing closed to prevent multi-process state corruption. "
                            "Install verified dependencies via 'pip install -r requirements.txt'."
                        )
                    logger.warning(
                        "portalocker not installed; falling back to threading.RLock strictly for "
                        "active pytest unit test execution."
                    )
            self._depth += 1
            return True
        except Exception:
            self._thread_lock.release()
            raise

    def release(self) -> None:
        if self._depth <= 0:
            return
        self._depth -= 1
        try:
            if self._depth == 0:
                if self._portalocker_lock is not None:
                    try:
                        self._portalocker_lock.release()
                    finally:
                        self._portalocker_lock = None
        finally:
            self._thread_lock.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()


class PaperSafetyViolation(RuntimeError):
    """Raised whenever an operation attempts to breach the PAPER trading boundary."""
    pass


class DeltaPaperBroker:
    """Manages simulated paper trading execution, risk sizing, and persistent state for XAUTUSD."""

    def __init__(
        self,
        cfg: Optional[ORBSettings] = None,
        state_file: Optional[Path] = None,
        initial_equity: Optional[float] = None,
        idempotency_db_path: Optional[Union[str, Path]] = None,
        gov_supervisor: Optional[Any] = None,
    ):
        self.cfg = cfg or default_orb_settings

        # Mandatory Governance Supervisor Integration (V7 Fail-Closed)
        if _SUPERVISOR_IMPORT_EXCEPTION is not None or GovernanceSupervisor is None:
            raise PaperSafetyViolation(
                f"FATAL: GovernanceSupervisor module failed to import: {_SUPERVISOR_IMPORT_EXCEPTION}. "
                "Fail-closed governance mandates an active supervisor."
            )

        if gov_supervisor is not None:
            self.gov_supervisor = gov_supervisor
        else:
            try:
                self.gov_supervisor = GovernanceSupervisor()
            except Exception as e:
                raise PaperSafetyViolation(
                    f"FATAL: Failed to construct GovernanceSupervisor: {e}. Fail-closed containment engaged."
                ) from e

        enforce_fn = getattr(self.gov_supervisor, "enforce_startup_governance_safety", None)
        if not callable(enforce_fn):
            raise PaperSafetyViolation(
                "FATAL: Injected gov_supervisor lacks mandatory 'enforce_startup_governance_safety' method or method is not callable."
            )

        # Fail-closed startup safety verification
        self.gov_supervisor.enforce_startup_governance_safety()

        # Hard safety verification
        if getattr(self.cfg, "mode", "PAPER") == "LIVE" and not getattr(self.cfg, "live_trading_enabled", False):
            if self.gov_supervisor:
                try:
                    self.gov_supervisor.record_incident("LIVE_ORDER_ATTEMPT", {"source": "broker_init_live_mode"}, severity="FATAL")
                except Exception:
                    pass
            raise PaperSafetyViolation("CRITICAL: Live trading requested in paper broker context.")

        self.initial_equity = float(initial_equity or getattr(self.cfg, "paper_initial_equity", 10000.0))
        self.state_file = Path(state_file) if state_file else (Path(self.cfg.state_path).parent / "paper_account_xautusd.json")
        self._lock = threading.RLock()
        self._process_lock = CrossProcessReentrantLock.get_lock(self.state_file.with_suffix(".lock"))

        # Durable Idempotency Registry (Phase 3.29)
        self.idempotency_db_path = Path(idempotency_db_path) if idempotency_db_path else self.state_file.with_suffix(".idempotency.db")
        self._idempotency_registry = DurableIdempotencyRegistry(self.idempotency_db_path)

        # In-memory account state
        self.cash_balance: float = self.initial_equity
        self.realized_pnl: float = 0.0
        self.total_fees: float = 0.0
        self.total_slippage: float = 0.0
        self.peak_equity: float = self.initial_equity
        self.open_position: Optional[Dict[str, Any]] = None
        self.closed_trades: List[Dict[str, Any]] = []
        self.last_order: Optional[Dict[str, Any]] = None
        self.order_history: List[Dict[str, Any]] = []

        # Concurrency & Idempotency State (Phase 3.25 & Phase 3.27)
        self._pending_reservation: Optional[Dict[str, Any]] = None
        self._processed_idempotency_keys: Dict[str, Dict[str, Any]] = {}
        self._reservation_generation: int = 0

        # Load persisted state if exists under cross-process lock
        with self._process_lock:
            self._load_state()

            # Fail-closed check: if the database experienced corruption recovery but the persistent
            # state file was missing or empty (no historical trades or keys to establish idempotency),
            # the broker must fail closed rather than accept potentially duplicated execution keys.
            if getattr(self._idempotency_registry, "had_corruption_recovery", False):
                has_history = bool(self.closed_trades or self._processed_idempotency_keys or self.open_position)
                if not has_history:
                    raise IdempotencyRegistryError(
                        "Cannot establish complete idempotency history: durable database was corrupted "
                        "and persistent state file is missing or contains zero historical trades. "
                        "Failing closed to prevent duplicate order execution."
                    )

            # Synchronize historical keys from state into durable registry
            self._idempotency_registry.sync_historical_keys(
                self._processed_idempotency_keys,
                self.closed_trades,
            )

    # -------------------------------------------------------------------------
    # Persistence
    # -------------------------------------------------------------------------

    def _load_state(self) -> None:
        """Load persistent paper account state from disk."""
        if not self.state_file.exists():
            self._save_state()
            return

        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.cash_balance = float(data.get("cash_balance", self.initial_equity))
            self.realized_pnl = float(data.get("realized_pnl", 0.0))
            self.total_fees = float(data.get("total_fees", 0.0))
            self.total_slippage = float(data.get("total_slippage", 0.0))
            self.peak_equity = float(data.get("peak_equity", self.cash_balance))
            self.open_position = data.get("open_position")
            self.closed_trades = data.get("closed_trades", [])
            self.last_order = data.get("last_order")
            self._processed_idempotency_keys = data.get("processed_idempotency_keys", {})
            self._reservation_generation = int(data.get("reservation_generation", 0))

            raw_res = data.get("pending_reservation")
            if raw_res:
                res_time = float(raw_res.get("timestamp_epoch", 0.0))
                res_ttl = float(raw_res.get("ttl_seconds", 30.0))
                expires_at = float(raw_res.get("expires_at_epoch", res_time + res_ttl))
                now_epoch = datetime.now(timezone.utc).timestamp()
                if now_epoch < expires_at:
                    self._pending_reservation = raw_res
                else:
                    self._pending_reservation = None
            else:
                self._pending_reservation = None

            logger.info(
                "Loaded persisted paper account state: Balance=$%.2f, Realized P&L=$%.2f, Closed Trades=%d, Open Position=%s, Idempotency Keys=%d",
                self.cash_balance,
                self.realized_pnl,
                len(self.closed_trades),
                "YES" if self.open_position else "NO",
                len(self._processed_idempotency_keys),
            )
            # Reconcile in-flight execution intents across stores
            self._recover_pending_execution_intents()
        except Exception as exc:
            logger.warning("Could not read paper account state file (%s); starting fresh: %s", self.state_file, exc)
            self._save_state()

    def _recover_pending_execution_intents(self) -> None:
        """Scan and deterministically resolve any in-flight EXECUTING intents in the durable registry."""
        if not hasattr(self, "_idempotency_registry") or not self._idempotency_registry:
            return
        try:
            pending = self._idempotency_registry.get_pending_intents()
            if not pending:
                return

            for intent in pending:
                key = intent.get("idempotency_key")
                token = intent.get("token")
                try:
                    meta = json.loads(intent.get("metadata_json") or "{}")
                except Exception:
                    meta = {}
                intent_order_id = intent.get("order_id") or meta.get("order_id")

                # Case 1: Open position already exists in JSON state with matching order/key
                if self.open_position and (
                    self.open_position.get("idempotency_key") == key or
                    self.open_position.get("order_id") == intent_order_id
                ):
                    logger.info("Crash recovery: Completing transition to COMMITTED for key '%s'.", key)
                    self._idempotency_registry.commit_execution(token, self.open_position)
                    self._processed_idempotency_keys[key] = {
                        "token": token,
                        "generation": intent.get("generation", 0),
                        "order_id": intent_order_id,
                        "trade_id": intent.get("trade_id") or meta.get("trade_id"),
                        "status": "FILLED",
                        "timestamp": self._now_iso(),
                    }
                # Case 2: Recorded in closed trades
                elif any(t.get("idempotency_key") == key for t in self.closed_trades):
                    logger.info("Crash recovery: Completing transition to COMMITTED for closed key '%s'.", key)
                    self._idempotency_registry.commit_execution(token, {"order_id": intent_order_id, "trade_id": intent.get("trade_id")})
                # Case 3: Position never made it to JSON state -> roll back intent
                else:
                    logger.warning("Crash recovery: Rolling back unpersisted execution intent for key '%s'.", key)
                    self._idempotency_registry.rollback_execution(token, reason="CRASH_RECOVERY_UNPERSISTED")
                    if self._pending_reservation and self._pending_reservation.get("token") == token:
                        self._pending_reservation = None
                        self._save_state()
        except Exception as exc:
            logger.error("Failed to recover pending execution intents: %s", exc)

    def _save_state(self) -> None:
        """Atomically persist paper account state to disk."""
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "symbol": self.cfg.symbol,
            "initial_equity": self.initial_equity,
            "cash_balance": round(self.cash_balance, 4),
            "realized_pnl": round(self.realized_pnl, 4),
            "total_fees": round(self.total_fees, 4),
            "total_slippage": round(self.total_slippage, 4),
            "peak_equity": round(self.peak_equity, 4),
            "open_position": self.open_position,
            "closed_trades": self.closed_trades,
            "pending_reservation": self._pending_reservation,
            "processed_idempotency_keys": self._processed_idempotency_keys,
            "reservation_generation": self._reservation_generation,
            "last_order": self.last_order,
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }
        temp_file = self.state_file.with_suffix(".tmp")
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            temp_file.replace(self.state_file)
        except Exception as exc:
            logger.error("Failed to persist paper account state: %s", exc)

    def reset_account(self, starting_equity: Optional[float] = None) -> None:
        """Explicitly reset paper account (only for testing or administrative reset)."""
        with self._process_lock:
            equity = float(starting_equity or self.initial_equity)
            self.initial_equity = equity
            self.cash_balance = equity
            self.realized_pnl = 0.0
            self.total_fees = 0.0
            self.total_slippage = 0.0
            self.peak_equity = equity
            self.open_position = None
            self.closed_trades = []
            self._pending_reservation = None
            self._processed_idempotency_keys = {}
            self._reservation_generation = 0
            if hasattr(self, "_idempotency_registry") and self._idempotency_registry:
                try:
                    self._idempotency_registry.clear()
                    self._idempotency_registry.checkpoint("TRUNCATE")
                except Exception as exc:
                    logger.warning("Failed to clear idempotency registry during account reset: %s", exc)
            self._save_state()
            logger.info("Paper account reset to $%.2f.", equity)

    # -------------------------------------------------------------------------
    # Atomic Order Slot Reservation & Idempotency (Phase 3.25 & 3.27)
    # -------------------------------------------------------------------------

    def reserve_order_slot(
        self,
        idempotency_key: str,
        strategy_name: str,
        direction: str,
        symbol: str,
        ttl_seconds: float = 30.0,
    ) -> Tuple[bool, str, Optional[str]]:
        """Atomically reserve the single available paper position slot.

        Ensures that concurrent threads/processes cannot race to submit duplicate orders
        before the first order establishes an open position.
        
        Returns:
            Tuple[bool, str, Optional[str]]: (success, message, reservation_token)
        """
        clean_key = str(idempotency_key or "").strip()
        if not clean_key:
            return False, "Invalid idempotency key: key cannot be empty or null", None

        with self._process_lock:
            self._load_state()

            # L1 Check: Fast-path in-memory cache
            if clean_key in self._processed_idempotency_keys:
                cached = self._processed_idempotency_keys[clean_key]
                return False, f"Duplicate order: idempotency key '{clean_key}' already processed with status {cached.get('status', 'COMPLETED')}", None

            # L2 Check: Durable SQLite Idempotency Registry (Phase 3.29)
            if self._idempotency_registry.is_executed(clean_key):
                rec = self._idempotency_registry.get_record(clean_key)
                trade_info = f" (trade_id={rec.get('trade_id')})" if rec and rec.get('trade_id') else ""
                return False, f"Duplicate order: idempotency key '{clean_key}' already executed in durable registry{trade_info}", None

            # L3 Check: Historical closed trades ledger fallback
            if any(t.get("idempotency_key") == clean_key for t in self.closed_trades):
                return False, f"Duplicate order: idempotency key '{clean_key}' already recorded in historical closed trades ledger", None

            if self.open_position is not None:
                return False, f"Position already open: {self.open_position['direction']} {self.open_position['lots']} lots {self.open_position['symbol']}", None

            now_epoch = datetime.now(timezone.utc).timestamp()

            # Check existing in-flight reservation
            if self._pending_reservation is not None:
                active_key = self._pending_reservation.get("idempotency_key")
                res_time = float(self._pending_reservation.get("timestamp_epoch", 0.0))
                res_ttl = float(self._pending_reservation.get("ttl_seconds", 30.0))
                expires_at = float(self._pending_reservation.get("expires_at_epoch", res_time + res_ttl))

                # If same key is requested while in-flight
                if active_key == clean_key and now_epoch < expires_at:
                    return False, f"Duplicate order: idempotency key '{clean_key}' already reserved in-flight", None

                if now_epoch < expires_at:
                    return False, f"Order slot currently reserved by in-flight order '{active_key}'", None
                else:
                    logger.warning("Clearing expired order reservation (age: %.1fs > %.1fs).", now_epoch - res_time, res_ttl)
                    self._pending_reservation = None

            # Fencing generation increment
            self._reservation_generation += 1
            gen = self._reservation_generation
            token = f"RES_GEN{gen}_{secrets.token_hex(8)}"
            ttl_val = float(ttl_seconds)

            # Atomic reservation in durable SQLite registry (Phase 3.29)
            reg_ok, reg_msg = self._idempotency_registry.reserve(
                idempotency_key=clean_key,
                token=token,
                generation=gen,
                strategy_name=strategy_name,
                direction=direction,
                symbol=symbol,
                ttl_seconds=ttl_val,
            )
            if not reg_ok:
                return False, reg_msg, None

            self._pending_reservation = {
                "token": token,
                "generation": gen,
                "idempotency_key": clean_key,
                "strategy_name": strategy_name,
                "direction": direction,
                "symbol": symbol,
                "ttl_seconds": ttl_val,
                "timestamp_epoch": now_epoch,
                "expires_at_epoch": now_epoch + ttl_val,
                "timestamp_iso": self._now_iso(),
            }
            self._save_state()
            logger.info("Order slot atomically reserved (token=%s, gen=%d, key=%s, ttl=%.1fs).", token, gen, clean_key, ttl_val)
            return True, "Slot reserved successfully", token

    def release_order_reservation(self, token: Optional[str], reason: str = "") -> bool:
        """Release an in-flight order reservation if the order failed or was rejected."""
        if not token:
            return False
        with self._process_lock:
            if not self._pending_reservation:
                self._load_state()
            if self._pending_reservation and self._pending_reservation.get("token") == token:
                key = self._pending_reservation.get("idempotency_key")
                self._idempotency_registry.release(token, reason=reason)
                self._pending_reservation = None
                self._save_state()
                logger.info("Order reservation %s (key=%s) safely released. Reason: %s", token, key, reason or "unspecified")
                return True
            return False

    def commit_order_reservation(self, token: Optional[str], order_record: Dict[str, Any]) -> bool:
        """Commit an in-flight order reservation upon successful simulated order fill."""
        if not token:
            return False
        with self._process_lock:
            if not self._pending_reservation:
                self._load_state()
            if not self._pending_reservation or self._pending_reservation.get("token") != token:
                logger.warning("Commit rejected: reservation token '%s' not found or preempted.", token)
                return False

            now_epoch = datetime.now(timezone.utc).timestamp()
            res_time = float(self._pending_reservation.get("timestamp_epoch", 0.0))
            res_ttl = float(self._pending_reservation.get("ttl_seconds", 30.0))
            expires_at = float(self._pending_reservation.get("expires_at_epoch", res_time + res_ttl))

            # Reject commit if reservation has expired past TTL (uncontended case)
            if now_epoch >= expires_at:
                logger.error("Order reservation %s expired before commit (age: %.1fs >= %.1fs TTL). Commit rejected.", token, now_epoch - res_time, res_ttl)
                self._idempotency_registry.release(token, reason="TTL_EXPIRED")
                self._pending_reservation = None
                self._save_state()
                return False

            # Commit in durable SQLite registry FIRST (ACID transaction)
            reg_ok, reg_msg = self._idempotency_registry.commit(token, order_record)
            if not reg_ok:
                logger.error("Durable registry commit failed for token %s: %s", token, reg_msg)
                self._pending_reservation = None
                self._save_state()
                return False

            key = self._pending_reservation.get("idempotency_key")
            gen = self._pending_reservation.get("generation", self._reservation_generation)
            self._processed_idempotency_keys[key] = {
                "token": token,
                "generation": gen,
                "order_id": order_record.get("order_id"),
                "trade_id": order_record.get("trade_id"),
                "status": "FILLED",
                "timestamp": self._now_iso(),
            }
            # Prune if exceeding 1000 entries
            if len(self._processed_idempotency_keys) > 1000:
                sorted_keys = sorted(
                    self._processed_idempotency_keys.items(),
                    key=lambda item: item[1].get("timestamp", ""),
                )
                self._processed_idempotency_keys = dict(sorted_keys[-1000:])

            self._pending_reservation = None
            self._save_state()
            logger.info("Order reservation %s (gen=%s) committed into durable registry and cache.", token, gen)
            return True

    # -------------------------------------------------------------------------
    # Utilities
    # -------------------------------------------------------------------------

    @staticmethod
    def _now_iso() -> str:
        """Return current UTC timestamp in ISO-8601 format."""
        return datetime.now(timezone.utc).isoformat()

    # -------------------------------------------------------------------------
    # Hard Safety Guard (Blocks Live Execution)
    # -------------------------------------------------------------------------

    def execute_live_order(self, *args, **kwargs) -> Any:
        """Strictly blocks any live exchange order call and engages Tier 0 containment."""
        if self.gov_supervisor:
            try:
                self.gov_supervisor.record_incident(
                    "LIVE_ORDER_ATTEMPT",
                    details={"args": str(args), "kwargs": str(kwargs), "source": "DeltaPaperBroker.execute_live_order"},
                    severity="FATAL",
                )
            except Exception:
                pass
        raise PaperSafetyViolation(
            "CRITICAL SECURITY VIOLATION: execute_live_order was invoked on DeltaPaperBroker. "
            "Real order submission is strictly prohibited in PAPER mode. Tier 0 containment engaged."
        )

    # -------------------------------------------------------------------------
    # Fee Scenarios & Cost Modeling
    # -------------------------------------------------------------------------

    def _get_fee_rates(self) -> Tuple[float, float]:
        """Return (entry_fee_pct, exit_fee_pct) based on configured fee_scenario.
        
        Scenarios:
        - MAKER_MAKER: 0.01% entry, 0.01% exit (passive limit orders on both sides)
        - MAKER_TAKER: 0.01% entry, 0.05% exit (limit entry, stop-market / taker exit)
        - TAKER_TAKER: 0.05% entry, 0.05% exit (aggressive market orders on both sides)
        """
        scenario = getattr(self.cfg, "fee_scenario", "MAKER_MAKER").upper()
        maker = getattr(self.cfg, "maker_fee_pct", 0.01)
        taker = getattr(self.cfg, "taker_fee_pct", 0.05)

        if scenario == "MAKER_TAKER":
            return maker, taker
        elif scenario == "TAKER_TAKER":
            return taker, taker
        else:  # MAKER_MAKER or fallback to fee_pct_per_side
            fee = getattr(self.cfg, "fee_pct_per_side", maker)
            return fee, fee

    # -------------------------------------------------------------------------
    # Simulated Order Execution
    # -------------------------------------------------------------------------

    def open_simulated_trade(
        self,
        symbol: str,
        direction: str,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        lots: int,
        strategy_name: str,
        signal_reason: str = "",
        candle_timestamp: Optional[str] = None,
        order_type: str = "LIMIT",
        bar_high: Optional[float] = None,
        bar_low: Optional[float] = None,
        fill_ratio: float = 1.0,
        market_regime: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Open a simulated paper position with realistic friction (spread, slippage, fees).
        
        Supports:
        - Maker orders that fill vs. do not fill (based on bar high/low price bounds)
        - Partial fills (via fill_ratio between 0.0 and 1.0) with exchange integer lot increment
        - Zero fills (returns False, creates NO position, locks NO margin, charges ZERO fees)
        - Regime-dependent spread & slippage (wider during volatile breakouts)
        - Configurable fee scenarios and Indian GST (18%)
        - Atomic slot reservation and idempotency keys (Phase 3.25)
        """
        clean_dir = direction.strip().upper()
        clean_sym = symbol.strip().upper()
        order_kind = order_type.strip().upper()

        # Tier 0 Governance Circuit Breaker Check
        if self.gov_supervisor and self.gov_supervisor.has_active_breach():
            logger.critical("Order rejected: Tier 0 governance circuit breaker active containment.")
            return False, "GOVERNANCE_CONTAINMENT: Active governance breach detected in ledger. Execution halted.", None

        if clean_dir not in {"LONG", "SHORT"}:
            return False, f"Invalid direction: '{clean_dir}'", None
        if entry_price <= 0 or stop_loss <= 0 or take_profit <= 0:
            return False, "Invalid price parameters (entry, SL, TP must be positive)", None
        # FINAL ORDER BOUNDARY: Central Hard Position-Sizing Safety Guard (Phase 3.23)
        try:
            validated_lots = validate_paper_order_lots(lots)
        except PositionSizeViolation as e:
            order_info = {
                "status": "REJECTED",
                "reason": "SECURITY_SIZING_VIOLATION",
                "violation_code": e.violation_code,
                "requested_lots": lots,
                "filled_lots": 0,
                "unfilled_lots": 0,
                "rejection_message": str(e),
            }
            self.last_order = order_info
            logger.error(
                "[FINAL_BOUNDARY_REJECTION] Order rejected by Central Position Size Guard: %s",
                e,
            )
            return False, f"Position Size Guard Rejection: {e}", None

        # Resolve or generate deterministic idempotency key (Phase 3.25)
        if idempotency_key:
            resolved_idemp_key = idempotency_key
        elif candle_timestamp:
            resolved_idemp_key = f"IDEMP_{clean_sym}_{clean_dir}_{candle_timestamp}_{lots}"
        else:
            resolved_idemp_key = f"IDEMP_{clean_sym}_{clean_dir}_{self._now_iso()}_{secrets.token_hex(4)}"

        with self._process_lock:
            # 1. Atomic Order Slot Reservation & In-Flight Concurrency Check
            reserved, res_msg, res_token = self.reserve_order_slot(
                idempotency_key=resolved_idemp_key,
                strategy_name=strategy_name,
                direction=clean_dir,
                symbol=clean_sym,
            )
            if not reserved:
                return False, res_msg, None

            try:
                # 2. Check Maker Limit order fill condition (orders that do NOT fill due to price range)
                if order_kind == "LIMIT":
                    if clean_dir == "LONG" and bar_low is not None and bar_low > entry_price:
                        msg = f"Maker LIMIT BUY unfilled: bar low (${bar_low:.2f}) > limit entry (${entry_price:.2f})"
                        logger.info(msg)
                        self.last_order = {
                            "status": "UNFILLED",
                            "reason": "PRICE_NOT_REACHED",
                            "order_type": "LIMIT",
                            "requested_lots": lots,
                            "filled_lots": 0,
                            "unfilled_lots": lots,
                            "limit_price": entry_price,
                            "bar_low": bar_low,
                        }
                        self.release_order_reservation(res_token, reason="PRICE_NOT_REACHED")
                        return False, msg, None
                    elif clean_dir == "SHORT" and bar_high is not None and bar_high < entry_price:
                        msg = f"Maker LIMIT SELL unfilled: bar high (${bar_high:.2f}) < limit entry (${entry_price:.2f})"
                        logger.info(msg)
                        self.last_order = {
                            "status": "UNFILLED",
                            "reason": "PRICE_NOT_REACHED",
                            "order_type": "LIMIT",
                            "requested_lots": lots,
                            "filled_lots": 0,
                            "unfilled_lots": lots,
                            "limit_price": entry_price,
                            "bar_high": bar_high,
                        }
                        self.release_order_reservation(res_token, reason="PRICE_NOT_REACHED")
                        return False, msg, None

                # 3. Dynamic regime-dependent spread & slippage multiplier
                regime = market_regime or "RANGING"
                if regime == "VOLATILE_BREAKOUT":
                    regime_multiplier = 1.5  # 50% wider spread and slippage under high volatility
                elif regime == "UNCERTAIN":
                    regime_multiplier = 1.25
                else:
                    regime_multiplier = 1.0

                # Compute fill price with realistic entry spread and slippage
                spread_half = ((self.cfg.spread_pct_round_trip / 2.0) * regime_multiplier) / 100.0
                slip_half = ((self.cfg.slippage_pct_round_trip / 2.0) * regime_multiplier) / 100.0

                if clean_dir == "LONG":
                    fill_price = round(entry_price * (1.0 + spread_half + slip_half), 2)
                else:
                    fill_price = round(entry_price * (1.0 - spread_half - slip_half), 2)

                # 4. Exchange-compatible integer lot partial fill modeling
                try:
                    clamped_ratio = max(0.0, min(1.0, float(fill_ratio)))
                except (ValueError, TypeError):
                    clamped_ratio = 0.0

                raw_fill = round(lots * clamped_ratio, 6)
                executed_lots = int(math.floor(raw_fill))
                unfilled_lots = lots - executed_lots

                # Support zero fills: if calculated fill quantity is 0 lots, DO NOT open a position
                if executed_lots <= 0:
                    msg = (
                        f"Zero fill on {order_kind} order: calculated fill quantity is 0 lots "
                        f"(requested {lots} lots, fill ratio {clamped_ratio:.2%}, lot increment 1)"
                    )
                    logger.info(msg)
                    self.last_order = {
                        "status": "ZERO_FILL",
                        "symbol": clean_sym,
                        "direction": clean_dir,
                        "order_type": order_kind,
                        "requested_lots": lots,
                        "filled_lots": 0,
                        "unfilled_lots": lots,
                        "fill_ratio": clamped_ratio,
                        "fees": 0.0,
                        "contract_qty": 0.0,
                    }
                    self.release_order_reservation(res_token, reason="ZERO_FILL")
                    return False, msg, None

                contract_qty = round(executed_lots * self.cfg.contract_size_xaut, 6)
                try:
                    validate_contract_quantity(contract_qty, self.cfg.contract_size_xaut)
                except PositionSizeViolation as e:
                    logger.error("[FINAL_BOUNDARY_REJECTION] Contract conversion violation: %s", e)
                    self.release_order_reservation(res_token, reason="CONTRACT_VIOLATION")
                    return False, f"Contract Conversion Guard Rejection: {e}", None
                notional = round(fill_price * contract_qty, 2)
                margin_required = round(notional / self.cfg.leverage, 2)

                entry_fee_pct, _ = self._get_fee_rates()
                if order_kind in {"MARKET", "TAKER"}:
                    entry_fee_pct = getattr(self.cfg, "taker_fee_pct", 0.05)

                entry_fee = round(notional * (entry_fee_pct / 100.0), 4)
                entry_gst = round(entry_fee * (self.cfg.gst_rate_pct / 100.0), 4) if getattr(self.cfg, "apply_gst", False) else 0.0
                slippage_cost = round(abs(fill_price - entry_price) * contract_qty, 4)

                # 5. Balance verification
                entry_outflow = entry_fee + entry_gst
                if self.cash_balance < (margin_required + entry_outflow):
                    self.release_order_reservation(res_token, reason="INSUFFICIENT_CASH")
                    return False, f"Insufficient paper cash: required ${margin_required + entry_outflow:.2f}, available ${self.cash_balance:.2f}", None

                if candle_timestamp:
                    try:
                        ts_str = str(candle_timestamp).replace("Z", "+00:00")
                        parsed_dt = datetime.fromisoformat(ts_str)
                        ts_fmt = parsed_dt.strftime("%Y%m%d_%H%M%S")
                    except Exception:
                        ts_fmt = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                else:
                    ts_fmt = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

                trade_id = f"PAPER_{ts_fmt}_{clean_dir}"
                order_id = f"ORD_{trade_id}"
                now_iso = datetime.now(timezone.utc).isoformat()

                pos = {
                    "trade_id": trade_id,
                    "order_id": order_id,
                    "idempotency_key": resolved_idemp_key,
                    "reservation_token": res_token,
                    "symbol": clean_sym,
                    "strategy_name": strategy_name,
                    "direction": clean_dir,
                    "side": clean_dir,
                    "entry_time": candle_timestamp or now_iso,
                    "entry_price": fill_price,
                    "signal_entry_price": entry_price,
                    "market_price": fill_price,
                    "lots": executed_lots,
                    "requested_lots": lots,
                    "filled_lots": executed_lots,
                    "unfilled_lots": unfilled_lots,
                    "contract_qty": contract_qty,
                    "stop_loss": stop_loss,
                    "take_profit": take_profit,
                    "margin": margin_required,
                    "order_type": order_kind,
                    "entry_order_type": order_kind,
                    "fill_ratio": clamped_ratio,
                    "market_regime": regime,
                    "fee_rate_pct": entry_fee_pct,
                    "entry_fee": entry_fee,
                    "entry_gst": entry_gst,
                    "exit_fee": 0.0,
                    "exit_gst": 0.0,
                    "slippage_cost": slippage_cost,
                    "unrealized_pnl": 0.0,
                    "signal_reason": signal_reason,
                }

                # Construct write-ahead intent payload
                intent_payload = {
                    "pos": pos,
                    "order_id": order_id,
                    "trade_id": trade_id,
                    "cash_outflow": entry_outflow,
                    "entry_fee": entry_fee,
                    "slippage_cost": slippage_cost,
                    "prev_cash_balance": self.cash_balance,
                    "new_cash_balance": round(self.cash_balance - entry_outflow, 4),
                }

                # Step 1: Durably log execution intent to SQLite WAL (Write-Ahead Intent)
                intent_ok, intent_msg = self._idempotency_registry.record_execution_intent(res_token, intent_payload)
                if not intent_ok:
                    self.release_order_reservation(res_token, reason=f"INTENT_FAILED: {intent_msg}")
                    return False, f"Order execution intent failed: {intent_msg}", None

                # Step 2: Mutate broker state atomically in-memory
                self.cash_balance = round(self.cash_balance - entry_outflow, 4)
                self.total_fees += entry_fee
                self.total_slippage += slippage_cost
                self.open_position = pos
                self.last_order = {
                    "order_id": order_id,
                    "trade_id": trade_id,
                    "status": "FILLED",
                    "direction": clean_dir,
                    "lots": executed_lots,
                    "price": fill_price,
                    "fees": entry_fee,
                }
                self._pending_reservation = None
                self._processed_idempotency_keys[resolved_idemp_key] = {
                    "token": res_token,
                    "generation": self._reservation_generation,
                    "order_id": order_id,
                    "trade_id": trade_id,
                    "status": "FILLED",
                    "timestamp": now_iso,
                }
                if len(self._processed_idempotency_keys) > 1000:
                    sorted_keys = sorted(
                        self._processed_idempotency_keys.items(),
                        key=lambda item: item[1].get("timestamp", ""),
                    )
                    self._processed_idempotency_keys = dict(sorted_keys[-1000:])

                # Step 3: Persist complete broker state to JSON (Atomic file replacement with fsync)
                self._save_state()

                # Step 4: Durably transition intent to COMMITTED in SQLite
                commit_ok, commit_msg = self._idempotency_registry.commit_execution(res_token, pos)
                if not commit_ok:
                    logger.warning("Post-save SQLite commit transition returned false for token %s: %s", res_token, commit_msg)

                msg = (
                    f"Simulated {clean_dir} filled: {executed_lots}/{lots} lots ({contract_qty} XAUT) @ ${fill_price:.2f} "
                    f"[SL: ${stop_loss:.2f}, TP: ${take_profit:.2f}, Margin: ${margin_required:.2f}, Fee: ${entry_fee:.4f}]"
                )
                logger.info(msg)
                return True, msg, dict(pos)
            except Exception as exc:
                if 'res_token' in locals() and res_token:
                    try:
                        self._idempotency_registry.rollback_execution(res_token, reason=f"EXECUTION_EXCEPTION: {exc}")
                        self.release_order_reservation(res_token, reason="EXECUTION_EXCEPTION")
                    except Exception:
                        pass
                raise

    def close_simulated_trade(
        self,
        exit_price: float,
        exit_reason: str,
        exit_timestamp: Optional[str] = None,
        order_type: Optional[str] = None,
        market_regime: Optional[str] = None,
        close_lots: Optional[int] = None,
        fill_ratio: float = 1.0,
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Close current open simulated position (fully or partially), calculate final P&L and friction, and record."""
        with self._process_lock:
            if self.open_position is None:
                return False, "No open simulated position to close.", None

            pos = dict(self.open_position)
            side = pos["direction"]
            open_lots = pos["lots"]
            entry_price = pos["entry_price"]

            # Determine lots to close
            if close_lots is not None:
                target_close = int(close_lots)
            else:
                clamped_exit_ratio = max(0.0, min(1.0, float(fill_ratio)))
                target_close = int(math.floor(round(open_lots * clamped_exit_ratio, 6)))

            if target_close <= 0:
                msg = f"Zero fill on exit order: 0 lots closed out of {open_lots} open lots. Position remains open."
                logger.info(msg)
                self.last_order = {
                    "status": "ZERO_FILL",
                    "open_lots": open_lots,
                    "closed_lots": 0,
                    "remaining_lots": open_lots,
                    "fees": 0.0,
                }
                return False, msg, None

            # Enforce ceiling: cannot close more quantity than current open position
            actual_close_lots = min(target_close, open_lots)
            remaining_lots = open_lots - actual_close_lots

            # Compute regime-dependent spread and slippage
            regime = market_regime or pos.get("market_regime") or "RANGING"
            if regime == "VOLATILE_BREAKOUT":
                regime_multiplier = 1.5
            elif regime == "UNCERTAIN":
                regime_multiplier = 1.25
            else:
                regime_multiplier = 1.0

            spread_half = ((self.cfg.spread_pct_round_trip / 2.0) * regime_multiplier) / 100.0
            slip_half = ((self.cfg.slippage_pct_round_trip / 2.0) * regime_multiplier) / 100.0

            if side == "LONG":
                # Long exits by selling at Bid
                exit_fill = round(exit_price * (1.0 - spread_half - slip_half), 2)
            else:
                # Short exits by buying at Ask
                exit_fill = round(exit_price * (1.0 + spread_half + slip_half), 2)

            close_contract_qty = round(actual_close_lots * self.cfg.contract_size_xaut, 6)
            exit_notional = round(exit_fill * close_contract_qty, 2)

            # Determine exit fee rate based on order type and scenario
            if order_type:
                resolved_exit_type = order_type.strip().upper()
                exit_fee_pct = getattr(self.cfg, "taker_fee_pct", 0.05) if resolved_exit_type in {"TAKER", "MARKET"} else getattr(self.cfg, "maker_fee_pct", 0.01)
            elif exit_reason.upper() in {"SL", "STOP_LOSS"} and getattr(self.cfg, "fee_scenario", "MAKER_MAKER") != "MAKER_MAKER":
                resolved_exit_type = "TAKER"
                exit_fee_pct = getattr(self.cfg, "taker_fee_pct", 0.05)
            else:
                _, exit_fee_pct = self._get_fee_rates()
                resolved_exit_type = "MAKER" if exit_fee_pct <= getattr(self.cfg, "maker_fee_pct", 0.01) else "TAKER"

            exit_fee = round(exit_notional * (exit_fee_pct / 100.0), 4)
            exit_gst = round(exit_fee * (self.cfg.gst_rate_pct / 100.0), 4) if getattr(self.cfg, "apply_gst", False) else 0.0
            exit_slippage = round(abs(exit_fill - exit_price) * close_contract_qty, 4)

            # Pro-rate entry costs for the closed portion
            portion = actual_close_lots / open_lots
            allocated_entry_fee = round(pos["entry_fee"] * portion, 4)
            allocated_entry_gst = round(pos.get("entry_gst", 0.0) * portion, 4)
            allocated_entry_slip = round(pos["slippage_cost"] * portion, 4)

            # Gross P&L on closed contracts
            if side == "LONG":
                gross_pnl = round((exit_price - pos["signal_entry_price"]) * close_contract_qty, 4)
            else:
                gross_pnl = round((pos["signal_entry_price"] - exit_price) * close_contract_qty, 4)

            brokerage_fee = round(allocated_entry_fee + exit_fee, 4)
            total_gst = round(brokerage_fee * (self.cfg.gst_rate_pct / 100.0), 4)
            deducted_gst = total_gst if getattr(self.cfg, "apply_gst", False) else 0.0

            total_price_impact = round(allocated_entry_slip + exit_slippage, 4)
            spread_cost = round(total_price_impact / 2.0, 4)
            slippage_cost = round(total_price_impact / 2.0, 4)
            total_friction = round(brokerage_fee + deducted_gst + total_price_impact, 4)
            net_pnl = round(gross_pnl - total_friction, 4)

            # Trade-level R-Multiple: Net P&L relative to planned risk on this closed quantity
            trade_risk_cash = round(abs(pos["entry_price"] - pos["stop_loss"]) * close_contract_qty, 4)
            trade_r_multiple = round(net_pnl / trade_risk_cash, 2) if trade_risk_cash > 0 else 0.0

            # Portfolio-level R-Multiple
            portfolio_risk_budget = self.initial_equity * (self.cfg.risk_pct / 100.0)
            portfolio_r_multiple = round(net_pnl / portfolio_risk_budget, 4) if portfolio_risk_budget > 0 else 0.0

            # Update cash balance: restore allocated entry cash and apply net_pnl
            self.cash_balance = round(self.cash_balance + net_pnl + allocated_entry_fee + allocated_entry_gst, 4)
            self.realized_pnl = round(self.realized_pnl + net_pnl, 4)
            self.total_fees = round(self.total_fees + exit_fee, 4)
            self.total_slippage = round(self.total_slippage + exit_slippage, 4)

            current_eq = self.get_account_summary()["equity"]
            self.peak_equity = max(self.peak_equity, current_eq)

            now_iso = datetime.now(timezone.utc).isoformat()
            closed_record = {
                "trade_id": pos["trade_id"],
                "order_id": pos.get("order_id", f"ORD_{pos['trade_id']}"),
                "symbol": pos["symbol"],
                "strategy_name": pos["strategy_name"],
                "direction": side,
                "side": side,
                "entry_time": pos["entry_time"],
                "entry_price": entry_price,
                "requested_lots": pos.get("requested_lots", open_lots),
                "filled_lots": actual_close_lots,
                "unfilled_lots": pos.get("unfilled_lots", 0),
                "remaining_lots": remaining_lots,
                "lots": actual_close_lots,
                "contract_qty": close_contract_qty,
                "stop_loss": pos["stop_loss"],
                "take_profit": pos["take_profit"],
                "exit_time": exit_timestamp or now_iso,
                "exit_price": exit_fill,
                "trigger_price": exit_price,
                "gross_pnl": gross_pnl,
                "entry_fee": allocated_entry_fee,
                "exit_fee": exit_fee,
                "brokerage_fee": brokerage_fee,
                "fees": brokerage_fee,
                "entry_gst": allocated_entry_gst,
                "exit_gst": exit_gst,
                "gst": total_gst,
                "gst_applied": getattr(self.cfg, "apply_gst", False),
                "fee_scenario": getattr(self.cfg, "fee_scenario", "MAKER_MAKER"),
                "entry_order_type": pos.get("order_type", "LIMIT"),
                "exit_order_type": resolved_exit_type,
                "fill_ratio": pos.get("fill_ratio", 1.0),
                "market_regime": regime,
                "spread_cost": spread_cost,
                "slippage_cost": slippage_cost,
                "slippage": total_price_impact,
                "total_friction": total_friction,
                "net_pnl": net_pnl,
                "r_multiple": trade_r_multiple,
                "trade_r_multiple": trade_r_multiple,
                "portfolio_r_multiple": portfolio_r_multiple,
                "trade_risk_cash": trade_risk_cash,
                "exit_reason": exit_reason,
                "signal_reason": pos.get("signal_reason", ""),
            }

            self.closed_trades.append(closed_record)

            if remaining_lots == 0:
                self.open_position = None
            else:
                pos["lots"] = remaining_lots
                pos["contract_qty"] = round(remaining_lots * self.cfg.contract_size_xaut, 6)
                pos["margin"] = round(pos["margin"] * (1.0 - portion), 2)
                pos["entry_fee"] = round(pos["entry_fee"] - allocated_entry_fee, 4)
                pos["entry_gst"] = round(pos.get("entry_gst", 0.0) - allocated_entry_gst, 4)
                pos["slippage_cost"] = round(pos["slippage_cost"] - allocated_entry_slip, 4)
                self.open_position = pos

            self._save_state()

            msg = (
                f"Simulated {side} closed {actual_close_lots}/{open_lots} lots via {exit_reason} @ ${exit_fill:.2f} "
                f"[Gross: ${gross_pnl:+.4f}, Friction: ${total_friction:.4f}, Net: ${net_pnl:+.4f} ({trade_r_multiple:+.2f}R trade / {portfolio_r_multiple:+.4f}R portfolio)]"
            )
            logger.info(msg)
            return True, msg, closed_record

    def checkpoint_db(self, mode: str = "TRUNCATE") -> Tuple[int, int, int]:
        """Execute an explicit WAL checkpoint on the broker's SQLite database."""
        with self._process_lock:
            return self._idempotency_registry.checkpoint(mode=mode)

    def backup_state(self, backup_dir: Union[str, Path]) -> Tuple[Path, Path]:
        """Atomically back up both JSON state and the SQLite database to a backup directory.
        
        Uses SQLite's Online Backup API to ensure dirty WAL pages are safely captured.
        """
        with self._process_lock:
            bdir = Path(backup_dir)
            bdir.mkdir(parents=True, exist_ok=True)
            self._save_state()
            json_backup = bdir / self.state_file.name
            shutil.copy2(self.state_file, json_backup)
            db_backup = bdir / self.idempotency_db_path.name
            self._idempotency_registry.backup_to_file(db_backup)
            return json_backup, db_backup

    # -------------------------------------------------------------------------
    # Position & SL/TP Evaluation
    # -------------------------------------------------------------------------

    def evaluate_open_position_sl_tp(
        self,
        current_price: float,
        high: Optional[float] = None,
        low: Optional[float] = None,
        timestamp: Optional[str] = None,
        close_lots: Optional[int] = None,
        tp_fill_ratio: float = 1.0,
        open_price: Optional[float] = None,
        require_penetration: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Check if active open position touched Stop Loss or Take Profit.
        
        Models:
        - SL as TAKER market exit with taker fees, slippage, and conservative gap-through-stop pricing.
        - TP as passive MAKER limit exit with maker fees and optional penetration requirement.
        - Conservative collision rule: if both SL and TP are touched in the same bar, SL wins.
        """
        with self._process_lock:
            if self.open_position is None:
                return None
            pos = dict(self.open_position)

        side = pos["direction"]
        sl = float(pos["stop_loss"])
        tp = float(pos["take_profit"])

        bar_high = float(high if high is not None else current_price)
        bar_low = float(low if low is not None else current_price)

        hit_sl = (bar_low <= sl) if side == "LONG" else (bar_high >= sl)

        # Realism: touching limit price does not guarantee a fill without penetration or queue priority
        if require_penetration:
            hit_tp = (bar_high > tp) if side == "LONG" else (bar_low < tp)
        else:
            hit_tp = (bar_high >= tp) if side == "LONG" else (bar_low <= tp)

        if hit_sl or hit_tp:
            # Conservative collision rule: if both SL and TP are touched in same bar, SL wins
            if hit_sl:
                # Conservative gap handling: if bar opened past stop loss, fill at the worse open price
                if side == "LONG":
                    exit_price = min(sl, float(open_price)) if open_price is not None else sl
                else:
                    exit_price = max(sl, float(open_price)) if open_price is not None else sl
                reason = "SL"
                order_type = "TAKER"
                exit_close_lots = None
                exit_fill_ratio = 1.0
            else:
                exit_price = tp
                reason = "TP"
                order_type = "MAKER"
                exit_close_lots = close_lots
                exit_fill_ratio = tp_fill_ratio

            ok_close, _, closed_trade = self.close_simulated_trade(
                exit_price=exit_price,
                exit_reason=reason,
                exit_timestamp=timestamp,
                order_type=order_type,
                close_lots=exit_close_lots,
                fill_ratio=exit_fill_ratio,
            )
            return closed_trade if ok_close else None

        # Otherwise update unrealized P&L
        with self._process_lock:
            if self.open_position is not None:
                qty = self.open_position["contract_qty"]
                e_price = self.open_position["entry_price"]
                if side == "LONG":
                    unrealized_gross = (current_price - e_price) * qty
                else:
                    unrealized_gross = (e_price - current_price) * qty
                self.open_position["market_price"] = current_price
                self.open_position["unrealized_pnl"] = round(unrealized_gross - pos["entry_fee"], 4)

        return None

    # -------------------------------------------------------------------------
    # Telemetry & Metrics
    # -------------------------------------------------------------------------

    def get_account_summary(self) -> Dict[str, Any]:
        """Return comprehensive simulated account summary and performance metrics."""
        with self._process_lock:
            pos = dict(self.open_position) if self.open_position else None
            unrealized_pnl = float(pos["unrealized_pnl"]) if pos else 0.0
            margin_used = float(pos["margin"]) if pos else 0.0
            equity = round(self.cash_balance + margin_used + unrealized_pnl, 4)
            trades = list(self.closed_trades)

        total_trades = len(trades)
        wins = [t for t in trades if t["net_pnl"] > 0]
        losses = [t for t in trades if t["net_pnl"] <= 0]
        win_rate = (len(wins) / total_trades * 100.0) if total_trades > 0 else 0.0

        gross_gains = sum(t["net_pnl"] for t in wins)
        gross_losses = abs(sum(t["net_pnl"] for t in losses))
        profit_factor = (gross_gains / gross_losses) if gross_losses > 0 else (999.0 if gross_gains > 0 else 0.0)

        # Drawdown calculation
        peak = self.initial_equity
        max_dd_cash = 0.0
        max_dd_pct = 0.0
        running_equity = self.initial_equity

        for t in trades:
            running_equity += t["net_pnl"]
            if running_equity > peak:
                peak = running_equity
            dd_cash = peak - running_equity
            dd_pct = (dd_cash / peak * 100.0) if peak > 0 else 0.0
            max_dd_cash = max(max_dd_cash, dd_cash)
            max_dd_pct = max(max_dd_pct, dd_pct)

        return {
            "mode": "PAPER",
            "symbol": self.cfg.symbol,
            "initial_equity": self.initial_equity,
            "cash_balance": round(self.cash_balance, 4),
            "margin_used": margin_used,
            "unrealized_pnl": round(unrealized_pnl, 4),
            "equity": equity,
            "realized_pnl": round(self.realized_pnl, 4),
            "total_fees": round(self.total_fees, 4),
            "total_slippage": round(self.total_slippage, 4),
            "total_trades": total_trades,
            "winning_trades": len(wins),
            "losing_trades": len(losses),
            "win_rate_pct": round(win_rate, 2),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown_pct": round(max_dd_pct, 2),
            "max_drawdown_cash": round(max_dd_cash, 2),
            "has_open_position": pos is not None,
            "open_position": pos,
            "closed_trades": trades,
        }
