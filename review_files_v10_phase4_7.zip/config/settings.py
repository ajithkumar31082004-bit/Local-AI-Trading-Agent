"""Application configuration and environment settings."""

import os
from pathlib import Path
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load local environment variables from .env if present
ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / ".env")


class Settings(BaseModel):
    """Central configuration for Local AI Trading Agent."""

    # Project paths
    project_root: Path = ROOT_DIR
    data_dir: Path = ROOT_DIR / "data"
    db_path: Path = ROOT_DIR / os.getenv("DATABASE_PATH", "data/trading_agent.db")

    # Ollama Local LLM Configuration
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.2:1b")
    ollama_timeout_seconds: int = int(os.getenv("OLLAMA_TIMEOUT_SECONDS", "60"))

    # Trading Mode
    paper_trading_enabled: bool = os.getenv("PAPER_TRADING_ENABLED", "true").lower() == "true"
    default_starting_balance: float = float(os.getenv("DEFAULT_STARTING_BALANCE", "100000.0"))
    currency: str = os.getenv("CURRENCY", "USD")

    # Risk Management Settings
    max_risk_per_trade_pct: float = float(os.getenv("MAX_RISK_PER_TRADE_PCT", "2.0"))  # % of equity at risk
    max_position_allocation_pct: float = float(os.getenv("MAX_POSITION_ALLOCATION_PCT", "20.0"))  # % of total portfolio per position
    max_daily_loss_pct: float = float(os.getenv("MAX_DAILY_LOSS_PCT", "5.0"))  # % daily max loss limit
    max_open_positions: int = int(os.getenv("MAX_OPEN_POSITIONS", "5"))
    default_stop_loss_pct: float = float(os.getenv("DEFAULT_STOP_LOSS_PCT", "2.5"))
    default_take_profit_pct: float = float(os.getenv("DEFAULT_TAKE_PROFIT_PCT", "5.0"))

    # Execution Costs
    transaction_fee_pct: float = float(os.getenv("TRANSACTION_FEE_PCT", "0.1"))  # 0.1% per trade
    default_slippage_pct: float = float(os.getenv("DEFAULT_SLIPPAGE_PCT", "0.05"))  # 0.05% slippage

    # Market Data
    data_cache_expiry_minutes: int = int(os.getenv("DATA_CACHE_EXPIRY_MINUTES", "5"))
    default_symbol: str = os.getenv("DEFAULT_SYMBOL", "AAPL")

    # Supabase Cloud Database Configuration
    supabase_enabled: bool = os.getenv("SUPABASE_ENABLED", "false").lower() == "true"
    supabase_url: str = os.getenv("SUPABASE_URL", "")
    supabase_key: str = os.getenv("SUPABASE_KEY", "")
    supabase_secret: str = os.getenv("SUPABASE_SECRET", "")
    supabase_publishable: str = os.getenv("SUPABASE_PUBLISHABLE", "")

    # Delta Exchange Configuration
    delta_exchange_enabled: bool = os.getenv("DELTA_EXCHANGE_ENABLED", "false").lower() == "true"
    delta_exchange_base_url: str = os.getenv("DELTA_EXCHANGE_BASE_URL", "https://api.india.delta.exchange").rstrip("/")
    delta_ws_base_url: str = os.getenv("DELTA_WS_BASE_URL", "wss://socket.india.delta.exchange")
    delta_exchange_api_key: str = os.getenv("DELTA_EXCHANGE_API_KEY", "")
    delta_exchange_api_secret: str = os.getenv("DELTA_EXCHANGE_API_SECRET", "")
    trading_mode: str = os.getenv("TRADING_MODE", os.getenv("ORB_MODE", "PAPER")).upper()
    live_trading_enabled: bool = os.getenv("LIVE_TRADING_ENABLED", "false").lower() == "true"
    paper_trading_acknowledged: str = os.getenv("PAPER_TRADING_ACKNOWLEDGED", "YES").upper()
    live_trading_acknowledged: str = os.getenv("LIVE_TRADING_ACKNOWLEDGED", "NO").upper()
    paper_initial_equity: float = float(os.getenv("PAPER_INITIAL_EQUITY", "10000.0"))
    emergency_kill_switch: bool = os.getenv("EMERGENCY_KILL_SWITCH", "false").lower() == "true"

    # NewsAPI Configuration
    newsapi_key: str = os.getenv("NEWSAPI_KEY", "")

    # Alpha Vantage Configuration
    alpha_vantage_api_key: str = os.getenv("ALPHA_VANTAGE_API_KEY", "")

    model_config = {"arbitrary_types_allowed": True}


# Global settings singleton
settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
